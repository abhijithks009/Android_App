package com.example.properapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.format.DateFormat;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.mynameismidori.currencypicker.CurrencyPicker;
import com.mynameismidori.currencypicker.CurrencyPickerListener;
import com.mynameismidori.currencypicker.ExtendedCurrency;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class UpdateActivity_expense extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText date_text;
    EditText time_text;
   // EditText name_text;
    Spinner account_spinner;
    TextView account_textview;
    TextView category_textview;
    EditText amount_text;
    EditText notes_text;
    Spinner category_spinner;
    Calendar calendar;
    ImageView date_icon;
    private long backPressedTime;
    private Toast backToast;
    ArrayList<ExpenseIncome> arrayList;
    Button insert_button;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;
    MyAdapter myAdapter;
    CategoryAdapter categoryAdapter;
    ArrayList<CategoryItem> categoryItemArrayList;
    String clickedCategoryName;
    Button bold,italics,underline,cross,update_button,delete_button;
    ExpenseIncome olditem;
    ImageView currencyset;
    String currencyname;
    String [] user = new String[2];

    @SuppressLint("SetTextI18n")
    @Nullable

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        myDB = new DatabaseHelper(this);
        account_textview =  findViewById(R.id.account_textview_update);
        category_textview =  findViewById(R.id.category_textview_update);
        date_text = (EditText) findViewById(R.id.date_edittext_update);
        time_text = (EditText) findViewById(R.id.time_edittext_update);
        account_spinner = (Spinner) findViewById(R.id.spinner_category2);
        amount_text = (EditText) findViewById(R.id.amount_edittext_update);
        notes_text = (EditText) findViewById(R.id.notes_editText_update);
        category_spinner = (Spinner) findViewById(R.id.spinner_update);
        currencyset=(ImageView) findViewById(R.id.currency);
        update_button = (Button) findViewById(R.id.update_button_update);
        delete_button = (Button) findViewById(R.id.delete_button);
        amount_text.setRawInputType(InputType.TYPE_CLASS_NUMBER);
        bold =(Button)findViewById(R.id.bold_button_update);
        italics =(Button)findViewById(R.id.italics_button_update);
        underline =(Button)findViewById(R.id.underline_button_update);
        cross =(Button)findViewById(R.id.deselect_button_update);
        myDB = new DatabaseHelper(getApplicationContext());
        user=myDB.get_currentuser();
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListner);

        date();
        initList();
        spinner();
        notes();
        update();
        delete();
        currency();

        Bundle extras = getIntent().getExtras();
        if(extras !=null)

        {
            olditem = (ExpenseIncome) getIntent().getSerializableExtra("serialize_data"); //Obtaining data

        }

        ArrayAdapter<String> my_spinner_adapter2 = new ArrayAdapter<String>(UpdateActivity_expense.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Account_Expense));
        my_spinner_adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int SelectedPosition = my_spinner_adapter2.getPosition(olditem.getAccount());

        ArrayAdapter<String> my_spinner_adapter = new ArrayAdapter<String>(UpdateActivity_expense.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Category));
        my_spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int selectionPosition = my_spinner_adapter.getPosition(olditem.category);

        assert olditem !=null;
        account_spinner.setAdapter(my_spinner_adapter2);
        account_spinner.setSelection(SelectedPosition);
        amount_text.setText(olditem.amount.toString());
        date_text.setText(olditem.date);
        time_text.setText(olditem.time);
        ExtendedCurrency currency = ExtendedCurrency.getCurrencyByName(olditem.currencyname);
        currencyset.setImageResource(currency.getFlag());
        currencyname=currency.getName();
        CharSequence Edit4 = Html.fromHtml(olditem.notes,1);
        notes_text.setText(Edit4);
        categoryAdapter = new CategoryAdapter(getApplicationContext(),categoryItemArrayList);
        category_spinner.setAdapter(categoryAdapter);
        category_spinner.setSelection(selectionPosition);

        if(olditem.category.equals("Lend") || olditem.category.equals("Borrow paid back")){
            account_spinner.setVisibility(View.INVISIBLE);
            account_textview.setVisibility(View.INVISIBLE);
            category_spinner.setVisibility(View.INVISIBLE);
            category_textview.setVisibility(View.INVISIBLE);
            update_button.setVisibility(View.INVISIBLE);
            String notes = olditem.notes;
            notes= olditem.account+"\n"+olditem.category+"\n"+notes;
            notes_text.setText(notes);
        }

    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    public void currency()
    {
        currencyset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final CurrencyPicker picker = CurrencyPicker.newInstance("Select Currency");  // dialog title
                picker.setListener(new CurrencyPickerListener() {
                    @Override
                    public void onSelectCurrency(String name, String code, String symbol, int flagDrawableResID) {
                        currencyset.setImageResource(flagDrawableResID);
                        currencyname=name;
                        picker.dismiss();

                    }
                });
                picker.show(getSupportFragmentManager(), "CURRENCY_PICKER");
            }
        });

    }
    public void initList() {
        categoryItemArrayList = new ArrayList<CategoryItem>();
        categoryItemArrayList.add(new CategoryItem("Shopping", R.drawable.gift_bag));
        categoryItemArrayList.add(new CategoryItem("Car", R.drawable.pickup_car));
        categoryItemArrayList.add(new CategoryItem("Entertainment", R.drawable.entertainment_60x60));
        categoryItemArrayList.add(new CategoryItem("Education", R.drawable.education_60x60));
        categoryItemArrayList.add(new CategoryItem("Food n Drink", R.drawable.food_60x60));
        categoryItemArrayList.add(new CategoryItem("Grocery", R.drawable.grocery_60x60));
        categoryItemArrayList.add(new CategoryItem("Health", R.drawable.insurance));
        categoryItemArrayList.add(new CategoryItem("Travel", R.drawable.travel_60x60));
        categoryItemArrayList.add(new CategoryItem("Other", R.drawable.other));

    }

    public void notes(){
        bold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();
                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalBOLD= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);
                int start = longDescription.length();


                longDescription.append(normalBOLD);
                longDescription.setSpan(new ForegroundColorSpan(Color.BLACK), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.setSpan(new StyleSpan(Typeface.BOLD), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);


                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });

        italics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();

                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalITALIC= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);
                int start = longDescription.length();
                longDescription.append(normalITALIC);
                longDescription.setSpan(new ForegroundColorSpan(Color.BLACK), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.setSpan(new StyleSpan(Typeface.ITALIC), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });

        underline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();

                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalUNDERLINE= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);
                int start = longDescription.length();
                longDescription.append(normalUNDERLINE);
                longDescription.setSpan(new ForegroundColorSpan(Color.BLACK), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.setSpan(new UnderlineSpan(), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });
        cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();

                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalDeselect= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);

                longDescription.append(normalDeselect.toString());

                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });


    }

    public void date()
    {

        Date date = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("d/M/yyyy");
        String formattedDate = dateFormat.format(date);
        date_text.setText(formattedDate);

        date_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                // month = month + 1;
                int year = calendar.get(Calendar.YEAR);

                datePickerDialog = new DatePickerDialog(UpdateActivity_expense.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        date_text.setText(dayOfMonth+"/"+(month+1)+"/"+year);

                    }

                },year,month,day);
                datePickerDialog.show();
            }
        });

        time_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(UpdateActivity_expense.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timepicker, int hourOfDay, int minute) {
                        time_text.setText(hourOfDay+":"+minute);
                    }
                },hour,minute, DateFormat.is24HourFormat(UpdateActivity_expense.this));
                timePickerDialog.show();
            }
        });

    }

    public void spinner()
    {
        categoryAdapter = new CategoryAdapter(getApplicationContext(),categoryItemArrayList);
        category_spinner.setAdapter(categoryAdapter);

        ArrayAdapter<String> my_spinner_adapter2 = new ArrayAdapter<String>(UpdateActivity_expense.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Account_Expense));
        my_spinner_adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        account_spinner.setAdapter(my_spinner_adapter2);


        category_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CategoryItem clickedItem = (CategoryItem)parent.getItemAtPosition(position);
                clickedCategoryName = clickedItem.getCategoryName();
                //  Toast.makeText(getActivity(), clickedCategoryName +" selected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void setcurrencyrate(final String date) {
        Thread thread99 = new Thread(new Runnable() {

            @Override
            public void run() {
                HttpURLConnection urlConnection = null;
                try {
                    try {
                        String mainUrl = "http://data.fixer.io/api/latest?access_key=1c28ba134bb0a7537ffd573c16f372be&format=1";
                        String updatedUrl = mainUrl;
                        URL url = new URL(updatedUrl);


                        urlConnection = (HttpURLConnection) url.openConnection();

                        InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                        BufferedReader inReader = new BufferedReader(new InputStreamReader(in));
                        String inputLine = "";
                        String fullStr = "";
                        while ((inputLine = inReader.readLine()) != null) {
                            fullStr += inputLine;
                        }

                        JSONObject jsonObj = new JSONObject(fullStr);
                        JSONObject result = jsonObj.getJSONObject("rates");


                        ExtendedCurrency[] currencies = ExtendedCurrency.CURRENCIES;
                        int i = 0, l = 0;
                        l = currencies.length;
                        String[] codes = new String[l];
                        while (i < l) {
                            codes[i] = currencies[i].getCode();
                            i = i + 1;
                        }

                        for (i = 0; i < l; i++) {
                            Double rateValue = Double.valueOf(result.getString(codes[i]));
                            boolean inserted = myDB.insertcurrency_rate_date(codes[i], rateValue, date);
                        }


                    } finally {
                        if (urlConnection != null)
                            urlConnection.disconnect();


                    }


                } catch (NumberFormatException e) {
                    //TODO: Alertbox ekle

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        double result = myDB.getcurrency_rate_date("EUR", date_text.getText().toString());
        if (result == 0) {
            thread99.start();
            try {
                thread99.join();


            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    public void update() {

        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = 0;
                boolean inserted=false;
                setcurrencyrate(date_text.getText().toString());

                if (amount_text.length() == 0) {
                    amount_text.setError("Enter Amount");
                    i++;
                }
                if(amount_text.length() > 7)
                {
                    amount_text.setError("Amount too big");
                    i++;
                }

                if (date_text.length() == 0) {
                    date_text.setError("Enter Date");
                    i++;
                }
                if (i == 0) {//
                    String notes = Html.toHtml(notes_text.getText(), 1);
                    if (myDB.getcurrency_rate_date("EUR", date_text.getText().toString()) != 0) {
                        inserted = myDB.updateData(olditem.ID.toString(), olditem.account, Double.parseDouble(amount_text.getText().toString()), olditem.category, date_text.getText().toString(), time_text.getText().toString(), notes, olditem.incomeexpense, "NORMAL", currencyname, user[0], user[1],olditem.contactname,olditem.contactphonenumbers,olditem.contactemails);
                    }if (inserted) {
                        Toast.makeText(getApplicationContext(), "Value updated", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Value not updated", Toast.LENGTH_LONG).show();
                    }
                    Intent update = new Intent(UpdateActivity_expense.this, ListView.class);
                    startActivity(update);
                    finish();
                }
            }
        });

    }
    public void delete() {

        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean deleted = myDB.deleteDataExpense(olditem.ID.toString());
                if (deleted) {
                    Toast.makeText(getApplicationContext(), "Value deleted", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Value not deleted", Toast.LENGTH_LONG).show();
                }
                Intent update = new Intent(UpdateActivity_expense.this, ListView.class);
                startActivity(update);
                finish();
            }
        });


    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListner =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {
                        case R.id.Nav_Dashboard:

                            startActivity(new Intent(UpdateActivity_expense.this,MainActivity.class));
                            finish();

                            break;
                        case R.id.Nav_List:
                            Intent show1 = new Intent(UpdateActivity_expense.this, ListView.class);
                            startActivity(show1);
                            finish();
                            break;

                        case R.id.Nav_Add:
                            Intent show2 = new Intent(UpdateActivity_expense.this, ListView_Checked.class);
                            startActivity(show2);
                            finish();
                            break;
                    }
                    return true;
                }
            };
}
