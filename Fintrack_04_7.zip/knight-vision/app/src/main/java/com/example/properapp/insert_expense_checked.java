package com.example.properapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.format.DateFormat;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.mynameismidori.currencypicker.CurrencyPicker;
import com.mynameismidori.currencypicker.CurrencyPickerListener;
import com.mynameismidori.currencypicker.ExtendedCurrency;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class insert_expense_checked extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText date_text;
    EditText time_text;
   // EditText name_text;
   private long backPressedTime;
    private Toast backToast;
    Spinner account_spinner;
    EditText amount_text;
    EditText notes_text;
    Spinner category_spinner;
    Calendar calendar;
    ImageView date_icon;
    ArrayList<ExpenseIncome> arrayList;
    Button insert_button;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;
    MyAdapter myAdapter;
    CategoryAdapter categoryAdapter;
    ArrayList<CategoryItem> categoryItemArrayList;
    String clickedCategoryName;
    Button bold,italics,underline,cross,update_button,delete_button;
    ExpenseIncome olditem;
    CheckBox checkBox;
    String check;
    String currencyname;
    ImageView currency;
    String[] user = new String[2];
    @SuppressLint("SetTextI18n")
    @Nullable

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);
        myDB = new DatabaseHelper(this);
        date_text = (EditText) findViewById(R.id.date_edittext);
        time_text = (EditText) findViewById(R.id.time_edittext);
        account_spinner = (Spinner) findViewById(R.id.spinner_category2);
        amount_text = (EditText) findViewById(R.id.amount_edittext);
        notes_text = (EditText) findViewById(R.id.notes_editText);
        category_spinner = (Spinner) findViewById(R.id.spinner_category);
        amount_text.setRawInputType(InputType.TYPE_CLASS_NUMBER);
        bold =(Button)findViewById(R.id.bold_button);
        italics =(Button)findViewById(R.id.italics_button);
        underline =(Button)findViewById(R.id.underline_button);
        cross =(Button)findViewById(R.id.deselect_button);
        insert_button = (Button)findViewById(R.id.insert_button);
        checkBox =(CheckBox) findViewById(R.id.checkBox) ;
        myDB = new DatabaseHelper(getApplicationContext());
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListner);
        currency = (ImageView) findViewById(R.id.currency);
        user=myDB.get_currentuser();


        date();
        initList();
        spinner();
        notes();
        checkBox_check();
        insertData();
        currency();
        Bundle extras = getIntent().getExtras();
        if(extras !=null)

        {
            olditem = (ExpenseIncome) getIntent().getSerializableExtra("serialize_data"); //Obtaining data

        }

        ArrayAdapter<String> my_spinner_adapter2 = new ArrayAdapter<String>(insert_expense_checked.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Account_Expense));
        my_spinner_adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int SelectedPosition = my_spinner_adapter2.getPosition(olditem.getAccount());

        ArrayAdapter<String> my_spinner_adapter = new ArrayAdapter<String>(insert_expense_checked.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Category));
        my_spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        int selectionPosition = my_spinner_adapter.getPosition(olditem.category);

        assert olditem !=null;
        account_spinner.setAdapter(my_spinner_adapter2);
        account_spinner.setSelection(SelectedPosition);
        amount_text.setText(olditem.amount.toString());
        ExtendedCurrency currencyset = ExtendedCurrency.getCurrencyByName(olditem.currencyname);
        currency.setImageResource(currencyset.getFlag());
        currencyname=currencyset.getName();
        CharSequence Edit4 = Html.fromHtml(olditem.notes,1);
        notes_text.setText(Edit4);
        categoryAdapter = new CategoryAdapter(getApplicationContext(),categoryItemArrayList);
        category_spinner.setAdapter(categoryAdapter);
        category_spinner.setSelection(selectionPosition);



    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    public void checkBox_check()
    {
        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox.isChecked())
                {
                    check = "CHECKED";
                }
                else
                {
                    check = "NORMAL";
                }
            }
        });
    }

    public void currency()
    {
        currency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CurrencyPicker picker = CurrencyPicker.newInstance("Select Currency");  // dialog title
                picker.setListener(new CurrencyPickerListener() {
                    @Override
                    public void onSelectCurrency(String name, String code, String symbol, int flagDrawableResID) {
                        currency.setImageResource(flagDrawableResID);
                        currencyname=name;

                    }
                });
                picker.show(getSupportFragmentManager(), "CURRENCY_PICKER");
            }
        });

    }

    public void initList() {
        categoryItemArrayList = new ArrayList<CategoryItem>();
        categoryItemArrayList.add(new CategoryItem("Shopping", R.drawable.gift_bag));
        categoryItemArrayList.add(new CategoryItem("Car", R.drawable.pickup_car));
        categoryItemArrayList.add(new CategoryItem("Entertainment", R.drawable.entertainment_60x60));
        categoryItemArrayList.add(new CategoryItem("Education", R.drawable.education_60x60));
        categoryItemArrayList.add(new CategoryItem("Food n Drink", R.drawable.food_60x60));
        categoryItemArrayList.add(new CategoryItem("Grocery", R.drawable.grocery_60x60));
        categoryItemArrayList.add(new CategoryItem("Health", R.drawable.insurance));
        categoryItemArrayList.add(new CategoryItem("Travel", R.drawable.travel_60x60));
        categoryItemArrayList.add(new CategoryItem("Other", R.drawable.other));

    }

    public void notes(){
        bold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();
                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalBOLD= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);
                int start = longDescription.length();


                longDescription.append(normalBOLD);
                longDescription.setSpan(new ForegroundColorSpan(Color.BLACK), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.setSpan(new StyleSpan(Typeface.BOLD), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);


                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });

        italics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();

                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalITALIC= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);
                int start = longDescription.length();
                longDescription.append(normalITALIC);
                longDescription.setSpan(new ForegroundColorSpan(Color.BLACK), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.setSpan(new StyleSpan(Typeface.ITALIC), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });

        underline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();

                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalUNDERLINE= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);
                int start = longDescription.length();
                longDescription.append(normalUNDERLINE);
                longDescription.setSpan(new ForegroundColorSpan(Color.BLACK), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.setSpan(new UnderlineSpan(), start, longDescription.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });
        cross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int startSelection=notes_text.getSelectionStart();
                int endSelection=notes_text.getSelectionEnd();

                Spannable ss = new SpannableString(notes_text.getText());
                CharSequence normalBefore= ss.subSequence(0,startSelection);
                CharSequence normalAfter= ss.subSequence(endSelection,notes_text.length());
                CharSequence normalDeselect= ss.subSequence(startSelection,endSelection);
                SpannableStringBuilder longDescription = new SpannableStringBuilder();
                longDescription.append(normalBefore);

                longDescription.append(normalDeselect.toString());

                longDescription.append(normalAfter);

                notes_text.setText(longDescription);

            }
        });


    }

    public void date()
    {

        Date date = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("d/M/yyyy");
        String formattedDate = dateFormat.format(date);
        date_text.setText(formattedDate);

        date_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                // month = month + 1;
                int year = calendar.get(Calendar.YEAR);

                datePickerDialog = new DatePickerDialog(insert_expense_checked.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        date_text.setText(dayOfMonth+"/"+(month+1)+"/"+year);

                    }

                },year,month,day);
                datePickerDialog.show();
            }
        });
        Calendar c = Calendar.getInstance();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        String formattedTime = timeFormat.format(c.getTime());
        time_text.setText(formattedTime);

        time_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(insert_expense_checked.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timepicker, int hourOfDay, int minute) {
                        time_text.setText(hourOfDay+":"+minute);
                    }
                },hour,minute, DateFormat.is24HourFormat(insert_expense_checked.this));
                timePickerDialog.show();
            }
        });

    }

    public void spinner()
    {
        categoryAdapter = new CategoryAdapter(getApplicationContext(),categoryItemArrayList);
        category_spinner.setAdapter(categoryAdapter);

        ArrayAdapter<String> my_spinner_adapter2 = new ArrayAdapter<String>(insert_expense_checked.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.Account_Expense));
        my_spinner_adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        account_spinner.setAdapter(my_spinner_adapter2);


        category_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CategoryItem clickedItem = (CategoryItem)parent.getItemAtPosition(position);
                clickedCategoryName = clickedItem.getCategoryName();
                //  Toast.makeText(getActivity(), clickedCategoryName +" selected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    public void insertData()
    {
        insert_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = 0;

                if (amount_text.length() == 0) {
                    amount_text.setError("Enter Amount");
                    i++;
                }


                if (date_text.length() == 0) {
                    date_text.setError("Enter Date");
                    i++;
                }
                if (i == 0) {
                    String notes = Html.toHtml(notes_text.getText(),1);
                    boolean inserted = myDB.insertData(account_spinner.getSelectedItem().toString(), Double.parseDouble(amount_text.getText().toString()), clickedCategoryName, date_text.getText().toString(),time_text.getText().toString(),notes,"expense",check,currencyname,user[0],user[1],olditem.contactname,olditem.contactphonenumbers,olditem.contactemails);
                    if (inserted) {
                        Toast.makeText(getApplicationContext(), "Value is Inserted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Value not Inserted", Toast.LENGTH_LONG).show();
                    }

                    startActivity(new Intent(getApplicationContext(), com.example.properapp.ListView.class));
                    finish();

                }
            }
        });
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListner =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {
                        case R.id.Nav_Dashboard:

                            startActivity(new Intent(insert_expense_checked.this,MainActivity.class));
                            finish();

                            break;
                        case R.id.Nav_List:
                            Intent show1 = new Intent(insert_expense_checked.this, ListView.class);
                            startActivity(show1);
                            finish();
                            break;

                        case R.id.Nav_Add:
                            Intent show2 = new Intent(insert_expense_checked.this, expense_income_tabbed_activity.class);
                            startActivity(show2);
                            finish();
                            break;
                    }
                    return true;
                }
            };
}
